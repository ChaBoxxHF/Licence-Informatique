def bbr(T):
    """ Retourne la liste des indices des cases à
    échanger pour obtenir un tableau à trois couleurs
    trié en bleu/blanc/rouge"""
    
